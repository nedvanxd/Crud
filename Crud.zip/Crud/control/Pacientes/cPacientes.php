<?php
/**
@author Artur Romao rocha
 */
$pasta="Pacientes"; 
require "model/Pacientes/mPacientes.php";

class cPacientes extends mPacientes { 
    private $pasta = "Pacientes";
    public function __construct() {
        $this->model = new mPacientes();
    }
    public function ivoke() {
        if (isset($_GET["visualizar"])) {
            $all = $this->ls($_GET["ID"]);
            $totalPagina = $this->getTotalpaginas();
            include "view/$this->pasta/visualizar.php";
        } elseif (isset($_GET["deletar"])) {
            if (isset($_GET["concordo"])) {
                $this->del($_GET["ID"]);
            }
            $all = $this->ls($_GET["ID"]);
            $total = $this->getTotalpaginas();
            include "view/$this->pasta/deletar.php";
        } elseif (isset($_GET["adicionar"])) {
            if (@$_GET["add"] == "true"  && isset($_POST[substr( $this->campochave,1,-1) ])) {
         

               @$uploadFoto = new UploadFoto($_FILES["PacientesReceita"], 500, 500, "img/");
                $uploadFoto->salvar();
                $_POST["PacientesReceita"] = $_SESSION["CaminhoParaArquivo"];
                    unset($_SESSION["CaminhoParaArquivo"]);
                
                $this->add(); 
                include "control/Pacientes/FmExe1.php";
                    }
            include "view/$this->pasta/adicionar.php";
        } elseif (isset($_GET["editar"])) {
            if (@$_GET["edt"] == "true"  && isset($_POST[substr( $this->campochave,1,-1) ])) { 
            if($_FILES["PacientesReceita"]["name"]!=""){
              @$uploadFoto = new UploadFoto($_FILES["PacientesReceita"], 500, 500, "img/");
                $uploadFoto->salvar();
                $_POST["PacientesReceita"] = $_SESSION["CaminhoParaArquivo"];
                    unset($_SESSION["CaminhoParaArquivo"]);
             }
                  $this->up($_GET["ID"]);  
                    @$c=$id;
                        
                        include "control/Pacientes/FmExe1.php";
                     }
            $all = $this->ls($_GET["ID"]);
            include "view/$this->pasta/editar.php";
        } elseif (isset($_GET["listar"])) {
            $all = $this->lst();
            $totalPagina = $this->getTotalpaginas();
            include "view/$this->pasta/listar.php";
        } else {
            $all = $this->lst();
            $totalPagina = $this->getTotalpaginas();
            include "view/$this->pasta/listar.php";
        }
    }
}

