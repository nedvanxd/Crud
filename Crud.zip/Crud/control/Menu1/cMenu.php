<?php
@session_start(); 
require 'model/Menu1/mMenu.php';  
class cMenu {
 public $model;
    function __construct() { 
      $this->model = new mMenu();
    }

}

?>