<?php
/**
@author Artur Romao rocha
 */
$pasta="Agendar"; 
require "model/Agendar/mAgendar.php";

class cAgendar extends mAgendar { 
    private $pasta = "Agendar";
    public function __construct() {
        $this->model = new mAgendar();
    }
    public function ivoke() {
        if (isset($_GET["visualizar"])) {
            $all = $this->ls($_GET["ID"]);
            $totalPagina = $this->getTotalpaginas();
            include "view/$this->pasta/visualizar.php";
        } elseif (isset($_GET["deletar"])) {
            if (isset($_GET["concordo"])) {
                $this->del($_GET["ID"]);
            }
            $all = $this->ls($_GET["ID"]);
            $total = $this->getTotalpaginas();
            include "view/$this->pasta/deletar.php";
        } elseif (isset($_GET["adicionar"])) {
            if (@$_GET["add"] == "true"  && isset($_POST[substr( $this->campochave,1,-1) ])) {
         

             
                $this->add(); 
                include "control/Agendar/FmExe1.php";
                    }
            include "view/$this->pasta/adicionar.php";
        } elseif (isset($_GET["editar"])) {
            if (@$_GET["edt"] == "true"  && isset($_POST[substr( $this->campochave,1,-1) ])) {    $this->up($_GET["ID"]);  
                    @$c=$id;
                        
                        include "control/Agendar/FmExe1.php";
                     }
            $all = $this->ls($_GET["ID"]);
            include "view/$this->pasta/editar.php";
        } elseif (isset($_GET["listar"])) {
            $all = $this->lst();
            $totalPagina = $this->getTotalpaginas();
            include "view/$this->pasta/listar.php";
        } else {
            $all = $this->lst();
            $totalPagina = $this->getTotalpaginas();
            include "view/$this->pasta/listar.php";
        }
    }
}

