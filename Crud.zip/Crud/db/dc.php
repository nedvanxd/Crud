
<html>
    <head>
        <title>Diagrama de Classe</title>
        <script src="../js/jquery.js" type="text/javascript"></script> 

        <style>

            .body{

                width: 1900px;
                height: 2750px; 
                margin-left: auto;
                margin-right: auto;
                position: absolute;
                margin-left: auto;
                margin-right: auto;



            }
            .caixa{
                background: #fff;
                position: inherit;
                min-width: 15px;
                max-width: 100%; 
                min-height: 15px; 
                border:5px solid #000;   

                color: #000;
                font-size: 25px;

            }
            .caixaLeg{
                padding: 10px; 
                text-align: center;
                border-bottom: 5px solid #000;

            }
            .caixaConte{ 
                text-align: left;
                border-bottom: 5px solid #000;
            }
            .caixaFk {           
                text-align: left;
            }

            .Item{
                padding: 10px; 
            } 

        </style>
    </head>

    <body> 
        <div class="body">

            <canvas id="c1c2"  width="1900" height="2750"></canvas>
            <script>
           // c1 e c2
                var $c = "";
                var $ctx = "";
                function redeclare() {
                    $c = document.getElementById("c1c2");
                    $ctx = $c.getContext("2d");
                    $ctx.beginPath();

                }
                redeclare();
                var $cor = 1;
                function linhas($de, $para) {



                    var $v = $("#" + $de).offset();
                    var $v2 = $("#" + $para).offset();
                    var $dif = $v.top -( $v2.top + $("#" + $para).height());
                    var $dif2 = $v.left - ($v2.left + ($("#" + $para).width() / 2));


                    if ($dif > 0) {
                        if ($v.left - ($v2.left + ($("#" + $para).width() / 2)) > ($("#" + $de).width())) {

                            //caminho
                            $ctx.moveTo($v.left + ($("#" + $de).width() / 2), $v.top);
                            $ctx.lineTo($v.left + ($("#" + $de).width() / 2), $v.top - $dif / 2);
                            $ctx.lineTo($v2.left + ($("#" + $para).width() / 2), $v.top - $dif / 2);
                            $ctx.lineTo($v2.left + ($("#" + $para).width() / 2), $v2.top + $("#" + $para).height());

                            //caminho


                        }


                        if ($v.left - ($v2.left + ($("#" + $para).width() / 2)) < ($("#" + $para).width())) {

                            $ctx.moveTo($v.left + ($("#" + $de).width() / 2), $v.top);
                            $ctx.lineTo($v.left + ($("#" + $de).width() / 2), $v.top - $dif / 2);
                            $ctx.lineTo($v2.left + ($("#" + $para).width() / 2), $v.top - $dif / 2);
                            $ctx.lineTo($v2.left + ($("#" + $para).width() / 2), $v2.top + $("#" + $para).height());


                        }




                        //ceta
                        $ctx.moveTo($v.left + ($("#" + $de).width() / 2), $v.top - 10);
                        $ctx.lineTo($v.left + ($("#" + $de).width() / 2) + 20, $v.top - 40);
                        $ctx.moveTo($v.left + ($("#" + $de).width() / 2), $v.top - 10);
                        $ctx.lineTo($v.left + ($("#" + $de).width() / 2) - 20, $v.top - 40);


                        $ctx.moveTo($v2.left + ($("#" + $para).width() / 2), $v2.top + $("#" + $para).height());
                        $ctx.lineTo($v2.left + ($("#" + $para).width() / 2) - 20, $v2.top + $("#" + $para).height() + 30);
                        $ctx.moveTo($v2.left + ($("#" + $para).width() / 2), $v2.top + $("#" + $para).height());
                        $ctx.lineTo($v2.left + ($("#" + $para).width() / 2) + 20, $v2.top + $("#" + $para).height() + 30);

                        //ceta








                    } else {
                        $dif = $v2.top - $v.top + $("#" + $de).height();

                        if ($v.left - ($v2.left + ($("#" + $para).width() / 2)) < ($("#" + $de).width())) {

                            //caminho
                            $ctx.moveTo($v.left + ($("#" + $de).width() / 2), $v.top + $("#" + $de).height());
                            $ctx.lineTo($v.left + ($("#" + $de).width() / 2), $v.top + $dif / 2);
                            $ctx.lineTo($v2.left + ($("#" + $para).width() / 2), $v.top + $dif / 2);
                            $ctx.lineTo($v2.left + ($("#" + $para).width() / 2), $v2.top);

                            //caminho


                        }


                        if ($v.left - ($v2.left + ($("#" + $para).width() / 2)) > ($("#" + $para).width())) {

                            $ctx.moveTo($v.left + ($("#" + $de).width() / 2), $v.top + $("#" + $de).height());
                            $ctx.lineTo($v.left + ($("#" + $de).width() / 2), $v.top + $dif / 2);
                            $ctx.lineTo($v2.left + ($("#" + $para).width() / 2), $v.top + $dif / 2);
                            $ctx.lineTo($v2.left + ($("#" + $para).width() / 2), $v2.top);


                        }




                        //ceta
                        $ctx.moveTo($v2.left + ($("#" + $para).width() / 2), $v2.top - 10);
                        $ctx.lineTo($v2.left + ($("#" + $para).width() / 2) + 20, $v2.top - 40);
                        $ctx.moveTo($v2.left + ($("#" + $para).width() / 2), $v2.top - 10);
                        $ctx.lineTo($v2.left + ($("#" + $para).width() / 2) - 20, $v2.top - 40);


                        $ctx.moveTo($v.left + ($("#" + $de).width() / 2), $v.top + $("#" + $de).height());
                        $ctx.lineTo($v.left + ($("#" + $de).width() / 2) - 20, $v.top + $("#" + $de).height() + 30);
                        $ctx.moveTo($v.left + ($("#" + $de).width() / 2), $v.top + $("#" + $de).height());
                        $ctx.lineTo($v.left + ($("#" + $de).width() / 2) + 20, $v.top + $("#" + $de).height() + 30);

                        //ceta 


                    }

                     var $r,$g,$b;
                     $r=Math.floor((Math.random() * 1) + 1);
                    
                    $ctx.strokeStyle = "black";
                    $ctx.lineWidth = 5;
                    $ctx.stroke();

              
                }
                function lp() {
                    $ctx.beginPath();
                    $ctx.fillStyle = "white";
                    $ctx.rect(0, 0, $c.width, $c.height);
                    $ctx.fill();

                }
               
            </script>
            <script src="../js/basico.js" type="text/javascript"></script>
            
            
            <div class ='caixa' id = 'Pacientes'>
                        <div class = 'caixaLeg'>Pacientes</div> 
                        <div class = 'caixaConte' >                        
                        <div class = 'item'>-PacientesId</div>
                                                                   
                        <div class = 'item'>-PacientesNome</div>
                                                                   
                        <div class = 'item'>-PacientesSexo</div>
                                                                   
                        <div class = 'item'>-PacientesCidade</div>
                                                                   
                        <div class = 'item'>-PacientesTelefone</div>
                                                                   
                        <div class = 'item'>-PacientesReceita</div>
                                               </div> </div>    <script> mxr(document.getElementById('Pacientes'));</script>     
   <script>$('#Pacientes').offset({top: Math.floor((Math.random() * 2680) + 1), left: Math.floor((Math.random() * 1800) + 1)});
                          </script>      <div class ='caixa' id = 'Agendar'>
                        <div class = 'caixaLeg'>Agendar</div> 
                        <div class = 'caixaConte' >                        
                        <div class = 'item'>-AgendarId</div>
                                                                   
                        <div class = 'item'>-AgendarData</div>
                                                                   
                        <div class = 'item'>-AgendarHora</div>
                                                                   
                        <div class = 'item'>-AgendarNome</div>
                                               </div> </div>    <script> mxr(document.getElementById('Agendar'));</script>     
   <script>$('#Agendar').offset({top: Math.floor((Math.random() * 2680) + 1), left: Math.floor((Math.random() * 1800) + 1)});
                          </script>        </div> <script>
                    function xlinhas() {
                    lp();

  }
 


    xlinhas();

</script> 
</body>
</html>
